This application is a scrumy app as a project for Linuxjobber Django Interns.

I hope this app helps you
