from django.apps import AppConfig


class BusayoscrummyConfig(AppConfig):
    name = 'busayoscrummy'
